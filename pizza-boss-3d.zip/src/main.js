import './style.css';
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { FBXLoader } from 'three/examples/jsm/loaders/FBXLoader.js';
import { clone as cloneSkinned } from 'three/examples/jsm/utils/SkeletonUtils.js';

/* ------------------------------------------------------------------ *
 * Pizza Boss 3D — v1
 * A single prep counter + one stove + one customer table.
 * Real Kenney models: food-kit (plate/toppings/pizza), furniture-kit
 * (shop interior), animated-characters (chef + customer).
 * Next versions: more customers, drive-thru lane, hired staff.
 * ------------------------------------------------------------------ */

const $ = (id) => document.getElementById(id);
const TOPPINGS = ['tomato', 'cheese', 'mush'];
const ICON = { tomato: '🍅', cheese: '🧀', mush: '🍄' };

// ---------------- Renderer / Scene / Camera ----------------
const canvasHost = document.getElementById('game');
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.shadowMap.enabled = true;
canvasHost.appendChild(renderer.domElement);

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x1b2733);
scene.fog = new THREE.Fog(0x1b2733, 12, 26);

const camera = new THREE.PerspectiveCamera(55, innerWidth / innerHeight, 0.1, 100);

function resize() {
  renderer.setSize(innerWidth, innerHeight);
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
}
addEventListener('resize', resize);
resize();

// ---------------- Lights ----------------
scene.add(new THREE.HemisphereLight(0xfff2d9, 0x33261a, 0.9));
const sun = new THREE.DirectionalLight(0xfff2d9, 1.1);
sun.position.set(4, 8, 3);
sun.castShadow = true;
sun.shadow.mapSize.set(1024, 1024);
sun.shadow.camera.left = -8; sun.shadow.camera.right = 8;
sun.shadow.camera.top = 8; sun.shadow.camera.bottom = -8;
scene.add(sun);

// ---------------- Loaders ----------------
const gltf = new GLTFLoader();
const fbx = new FBXLoader();
const loadGLB = (url) => new Promise((res, rej) => gltf.load(url, (g) => res(g.scene), undefined, rej));
const loadFBX = (url) => new Promise((res, rej) => fbx.load(url, res, undefined, rej));

function shadow(obj) {
  obj.traverse((n) => { if (n.isMesh) { n.castShadow = true; n.receiveShadow = true; } });
  return obj;
}

// asset URLs (Vite resolves these to hashed files at build time)
const A = {
  plate: new URL('./assets/food/plate.glb', import.meta.url).href,
  tomato: new URL('./assets/food/tomato-slice.glb', import.meta.url).href,
  cheese: new URL('./assets/food/cheese-cut.glb', import.meta.url).href,
  mush: new URL('./assets/food/mushroom.glb', import.meta.url).href,
  pizza: new URL('./assets/food/pizza.glb', import.meta.url).href,
  box: new URL('./assets/food/pizza-box.glb', import.meta.url).href,
  floor: new URL('./assets/shop/floorFull.glb', import.meta.url).href,
  wall: new URL('./assets/shop/wall.glb', import.meta.url).href,
  door: new URL('./assets/shop/wallDoorway.glb', import.meta.url).href,
  counter: new URL('./assets/shop/kitchenCabinet.glb', import.meta.url).href,
  stove: new URL('./assets/shop/kitchenStove.glb', import.meta.url).href,
  fridge: new URL('./assets/shop/kitchenFridge.glb', import.meta.url).href,
  table: new URL('./assets/shop/table.glb', import.meta.url).href,
  stool: new URL('./assets/shop/stoolBar.glb', import.meta.url).href,
  bin: new URL('./assets/shop/trashcan.glb', import.meta.url).href,
  charMesh: new URL('./assets/char/characterMedium.fbx', import.meta.url).href,
  idle: new URL('./assets/char/idle.fbx', import.meta.url).href,
  run: new URL('./assets/char/run.fbx', import.meta.url).href,
  skinChef: new URL('./assets/char/skaterMaleA.png', import.meta.url).href,
  skinGuest: new URL('./assets/char/skaterFemaleA.png', import.meta.url).href,
};

// ---------------- Build the shop room ----------------
const ROOM = 7; // half-size
async function buildRoom() {
  // floor tiles
  const floorTile = shadow(await loadGLB(A.floor));
  for (let x = -ROOM; x <= ROOM; x += 2) {
    for (let z = -ROOM; z <= ROOM; z += 2) {
      const t = floorTile.clone();
      t.position.set(x, 0, z);
      scene.add(t);
    }
  }
  // walls (three sides, leave front open)
  const wallProto = shadow(await loadGLB(A.wall));
  const place = (x, z, rotY) => { const w = wallProto.clone(); w.position.set(x, 0, z); w.rotation.y = rotY; scene.add(w); };
  for (let x = -ROOM; x <= ROOM; x += 2) place(x, -ROOM, 0);
  for (let z = -ROOM; z <= ROOM; z += 2) { place(-ROOM, z, Math.PI / 2); place(ROOM, z, Math.PI / 2); }
}

// ---------------- Stations ----------------
const stations = {}; // name -> { group, pos }
async function buildStations() {
  const counter = shadow(await loadGLB(A.counter));
  counter.position.set(-2.2, 0, -ROOM + 1.1);
  scene.add(counter);
  stations.prep = { pos: new THREE.Vector3(-2.2, 0, -ROOM + 2.3) };

  const stove = shadow(await loadGLB(A.stove));
  stove.position.set(0.2, 0, -ROOM + 1.1);
  scene.add(stove);
  stations.oven = { pos: new THREE.Vector3(0.2, 0, -ROOM + 2.3) };

  const fridge = shadow(await loadGLB(A.fridge));
  fridge.position.set(2.6, 0, -ROOM + 1.0);
  scene.add(fridge);

  const bin = shadow(await loadGLB(A.bin));
  bin.position.set(-4.4, 0, -ROOM + 0.8);
  scene.add(bin);

  const table = shadow(await loadGLB(A.table));
  table.position.set(2, 0, 2.5);
  scene.add(table);
  const stool = shadow(await loadGLB(A.stool));
  stool.position.set(2, 0, 3.6);
  stool.rotation.y = Math.PI;
  scene.add(stool);
  stations.serve = { pos: new THREE.Vector3(2, 0, 1.6) };
}

// ---------------- Character rig helper ----------------
async function makeCharacter(skinUrl) {
  const mesh = cloneSkinned(await loadFBX(A.charMesh));
  const tex = new THREE.TextureLoader().load(skinUrl);
  tex.flipY = false;
  mesh.traverse((n) => { if (n.isMesh) { n.material = new THREE.MeshStandardMaterial({ map: tex }); n.castShadow = true; } });
  mesh.scale.setScalar(0.011);
  const mixer = new THREE.AnimationMixer(mesh);
  const idleClip = (await loadFBX(A.idle)).animations[0];
  const runClip = (await loadFBX(A.run)).animations[0];
  const actions = { idle: mixer.clipAction(idleClip), run: mixer.clipAction(runClip) };
  actions.idle.play();
  return { mesh, mixer, actions, current: 'idle' };
}
function setAnim(ch, name) {
  if (ch.current === name) return;
  ch.actions[ch.current].fadeOut(0.15);
  ch.actions[name].reset().fadeIn(0.15).play();
  ch.current = name;
}

// ---------------- Prep pizza (real 3D models stacked on a plate) ----------------
let plateBase, plateTop = null, ovenPizza = null, carriedPizza = null;
const prep = { started: false, toppings: new Set() };

async function makePlateProto() { return shadow(await loadGLB(A.plate)); }
let toppingProtos = {};

function clearPrepVisual() {
  if (plateTop) { scene.remove(plateTop); plateTop = null; }
}
function rebuildPrepVisual() {
  clearPrepVisual();
  if (!prep.started) return;
  const g = new THREE.Group();
  let i = 0;
  for (const t of prep.toppings) {
    const m = toppingProtos[t].clone();
    const ang = i * 2.4, r = 0.12;
    m.position.set(Math.cos(ang) * r, 0.05 + i * 0.01, Math.sin(ang) * r);
    g.add(m); i++;
  }
  g.position.copy(stations.prep.pos).setY(1.0);
  scene.add(g);
  plateTop = g;
}

// ---------------- HUD wiring ----------------
function buildHud() {
  const hud = $('hud');
  hud.innerHTML = `
    <div class="top">
      <div class="stat">💰 <span id="money">30</span></div>
      <div class="stat">⭐ <span id="score">0</span></div>
    </div>
    <div class="toast" id="toast"></div>
    <div class="order" id="order" style="display:none"></div>
    <div class="bench">
      <div class="row">
        <button class="btn b-tomato" id="t-tomato">🍅</button>
        <button class="btn b-cheese" id="t-cheese">🧀</button>
        <button class="btn b-mush" id="t-mush">🍄</button>
        <button class="btn b-trash" id="t-trash">🗑️</button>
      </div>
      <div class="row">
        <button class="btn b-bake" id="t-bake">🔥 বেক করো</button>
        <button class="btn b-serve" id="t-serve">🍽️ সার্ভ করো</button>
      </div>
    </div>`;
  $('t-trash').onclick = () => { prep.started = false; prep.toppings.clear(); rebuildPrepVisual(); };
  ['tomato', 'cheese', 'mush'].forEach((t) => {
    $('t-' + t).onclick = () => {
      prep.started = true;
      prep.toppings.has(t) ? prep.toppings.delete(t) : prep.toppings.add(t);
      rebuildPrepVisual();
    };
  });
  $('t-bake').onclick = onBake;
  $('t-serve').onclick = onServe;
}
function toast(msg) {
  const t = $('toast'); t.textContent = msg; t.classList.add('on');
  clearTimeout(toast._h); toast._h = setTimeout(() => t.classList.remove('on'), 1300);
}
let money = 30, score = 0;
function addMoney(n) { money = Math.max(0, money + n); $('money').textContent = money; }
function addScore(n) { score += n; $('score').textContent = score; }

// ---------------- Orders ----------------
let order = null; // Set of toppings
function newOrder() {
  const n = 1 + Math.floor(Math.random() * 3);
  const s = new Set();
  while (s.size < n) s.add(TOPPINGS[Math.floor(Math.random() * TOPPINGS.length)]);
  order = s;
  $('order').style.display = 'flex';
  $('order').textContent = '👤 চাই: ' + [...s].map((t) => ICON[t]).join(' ');
}
function sameSet(a, b) { return a.size === b.size && [...a].every((x) => b.has(x)); }

// ---------------- Bake / Serve logic ----------------
let ovenTimer = 0, ovenBusy = false;
async function onBake() {
  if (!prep.started || prep.toppings.size === 0) return toast('আগে topping দাও');
  if (ovenBusy) return toast('ওভেন ব্যস্ত');
  if (dist(player.mesh.position, stations.oven.pos) > 2.2) return toast('ওভেনের কাছে যাও');
  ovenBusy = true; ovenTimer = 0;
  ovenPizza = { toppings: new Set(prep.toppings) };
  prep.started = false; prep.toppings.clear(); rebuildPrepVisual();
  toast('🔥 বেক হচ্ছে...');
}
async function onServe() {
  if (!carriedPizza) return toast('হাতে পিৎজা নেই');
  if (dist(player.mesh.position, stations.serve.pos) > 2.4) return toast('গ্রাহকের কাছে যাও');
  if (!order || !sameSet(order, carriedPizza.toppings)) { toast('❌ ভুল অর্ডার!'); return; }
  addMoney(20 + carriedPizza.toppings.size * 6);
  addScore(10);
  toast('✅ +💰 ' + (20 + carriedPizza.toppings.size * 6));
  scene.remove(carriedPizza.mesh);
  carriedPizza = null;
  newOrder();
}
function dist(a, b) { return Math.hypot(a.x - b.x, a.z - b.z); }

// ---------------- Player controls (virtual joystick) ----------------
const keys = { w: false, a: false, s: false, d: false };
addEventListener('keydown', (e) => { const k = e.key.toLowerCase(); if (k in keys) keys[k] = true; });
addEventListener('keyup', (e) => { const k = e.key.toLowerCase(); if (k in keys) keys[k] = false; });

let stickOrigin = null, stickVec = { x: 0, y: 0 };
let zoomFactor = 1, pinchStartDist = null, zoomStart = 1;
const ZOOM_MIN = 0.55, ZOOM_MAX = 2.2;

function handlePinch(e) {
  if (e.touches.length === 2) {
    const [a, b] = e.touches;
    const d = Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY);
    if (pinchStartDist == null) { pinchStartDist = d; zoomStart = zoomFactor; }
    else zoomFactor = THREE.MathUtils.clamp(zoomStart * (pinchStartDist / d), ZOOM_MIN, ZOOM_MAX);
    stickOrigin = null; stickVec = { x: 0, y: 0 }; // pinching cancels the walk joystick
  } else pinchStartDist = null;
}
renderer.domElement.addEventListener('touchstart', handlePinch, { passive: true });
renderer.domElement.addEventListener('touchmove', handlePinch, { passive: true });
renderer.domElement.addEventListener('touchend', () => { pinchStartDist = null; }, { passive: true });
addEventListener('wheel', (e) => {
  zoomFactor = THREE.MathUtils.clamp(zoomFactor + e.deltaY * 0.0012, ZOOM_MIN, ZOOM_MAX);
}, { passive: true });
const padEl = document.createElement('div');
padEl.className = 'pad';
addEventListener('DOMContentLoaded', () => $('hud').appendChild(padEl));
renderer.domElement.style.touchAction = 'none';
renderer.domElement.addEventListener('pointerdown', (e) => { stickOrigin = { x: e.clientX, y: e.clientY }; });
renderer.domElement.addEventListener('pointermove', (e) => {
  if (!stickOrigin) return;
  const R = 55;
  let dx = e.clientX - stickOrigin.x, dy = e.clientY - stickOrigin.y;
  const len = Math.hypot(dx, dy);
  if (len > R) { dx = dx / len * R; dy = dy / len * R; }
  stickVec = { x: dx / R, y: dy / R };
});
['pointerup', 'pointercancel', 'pointerleave'].forEach((ev) =>
  renderer.domElement.addEventListener(ev, () => { stickOrigin = null; stickVec = { x: 0, y: 0 }; }));

// ---------------- Main setup ----------------
let player, guest;
const clock = new THREE.Clock();

async function main() {
  buildHud();
  await buildRoom();
  await buildStations();

  toppingProtos = { tomato: await loadGLB(A.tomato), cheese: await loadGLB(A.cheese), mush: await loadGLB(A.mush) };
  plateBase = shadow(await loadGLB(A.plate));
  plateBase.position.copy(stations.prep.pos).setY(1.0);
  scene.add(plateBase);

  player = await makeCharacter(A.skinChef);
  player.mesh.position.set(0, 0, 2);
  scene.add(player.mesh);

  guest = await makeCharacter(A.skinGuest);
  guest.mesh.position.set(2, 0, 3.6);
  guest.mesh.rotation.y = Math.PI;
  scene.add(guest.mesh);

  newOrder();
  animate();
}

const SPEED = 2.6;
let camReady = false;
function updatePlayer(dt) {
  let vx = stickVec.x, vz = stickVec.y;
  if (keys.a) vx = -1; if (keys.d) vx = 1;
  if (keys.w) vz = -1; if (keys.s) vz = 1;
  const len = Math.hypot(vx, vz);
  if (len > 0.15) {
    vx /= (len > 1 ? len : 1); vz /= (len > 1 ? len : 1);
    player.mesh.position.x += vx * SPEED * dt;
    player.mesh.position.z += vz * SPEED * dt;
    player.mesh.position.x = THREE.MathUtils.clamp(player.mesh.position.x, -ROOM + 0.6, ROOM - 0.6);
    player.mesh.position.z = THREE.MathUtils.clamp(player.mesh.position.z, -ROOM + 0.6, ROOM - 0.6);
    player.mesh.rotation.y = Math.atan2(vx, vz);
    setAnim(player, 'run');
  } else setAnim(player, 'idle');

  const camPos = new THREE.Vector3(player.mesh.position.x, 8.5 * zoomFactor, player.mesh.position.z + 9.5 * zoomFactor);
  const look = player.mesh.position.clone().setY(1);
  if (!camReady) { camera.position.copy(camPos); camReady = true; }
  else camera.position.lerp(camPos, 1 - Math.pow(0.001, dt));
  camera.lookAt(look);
}

function animate() {
  requestAnimationFrame(animate);
  const dt = Math.min(clock.getDelta(), 0.05);
  player.mixer.update(dt);
  guest.mixer.update(dt);
  updatePlayer(dt);
  updateOvenSync(dt);
  if (carriedPizza) {
    carriedPizza.mesh.position.set(player.mesh.position.x, 1.0, player.mesh.position.z - 0.4);
    carriedPizza.mesh.rotation.y = player.mesh.rotation.y;
  }
  renderer.render(scene, camera);
}

// oven bake uses an async model load once, but must not block the frame loop;
// pre-load the pizza model once and just toggle visibility instead.
let pizzaProto = null, activePizzaMesh = null;
async function preloadPizza() { pizzaProto = shadow(await loadGLB(A.pizza)); pizzaProto.visible = false; scene.add(pizzaProto); }
function updateOvenSync(dt) {
  if (!ovenBusy) return;
  ovenTimer += dt;
  if (ovenTimer >= 3.2) {
    ovenBusy = false;
    const mesh = pizzaProto.clone();
    mesh.visible = true;
    mesh.position.copy(stations.oven.pos).setY(1.0);
    scene.add(mesh);
    carriedPizza = { mesh, toppings: ovenPizza.toppings };
    ovenPizza = null;
    toast('🍕 পিৎজা রেডি! সার্ভ করো');
  }
}

main().then(preloadPizza).catch((err) => {
  console.error(err);
  toast('❌ Asset load ব্যর্থ, কনসোল দেখো');
});
